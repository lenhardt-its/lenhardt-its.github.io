# PDF_Unblocker.ps1
$host.UI.RawUI.WindowTitle = "PDF Entsperr-Tool"
$ErrorActionPreference = "Continue"
$userDownloads = [System.IO.Path]::Combine($env:USERPROFILE, "Downloads")
$userDocuments = [Environment]::GetFolderPath('MyDocuments')
$ordnerListe = @($userDownloads, $userDocuments, "C:\Freigegebene\PDFs", "\\Server\Freigabe\PDFs")
Clear-Host
Write-Host "PDF ENTSPERR-TOOL" -ForegroundColor Cyan
Write-Host ""
$gesamtEntsperrt = 0
$gesamtFehler = 0
foreach ($ordner in $ordnerListe) {
    if ($ordner -and (Test-Path $ordner)) {
        $pdfs = Get-ChildItem -Path $ordner -Recurse -Filter *.pdf -ErrorAction SilentlyContinue
        $anzahl = $pdfs.Count
        if ($anzahl -gt 0) {
            Write-Host "Ordner: $ordner" -ForegroundColor Green
            Write-Host "   Gefundene PDF-Dateien: $anzahl"
            $entsperrt = 0
            foreach ($pdf in $pdfs) {
                try {
                    Unblock-File -Path $pdf.FullName
                    $entsperrt++
                    $gesamtEntsperrt++
                } catch {
                    Write-Host "   Fehler: $($pdf.Name)" -ForegroundColor Red
                    $gesamtFehler++
                }
            }
            Write-Host "   Erfolgreich entsperrt: $entsperrt" -ForegroundColor Yellow
        }
    } else {
        Write-Host "Ordner nicht gefunden: $ordner" -ForegroundColor Red
    }
    Write-Host ""
}
Write-Host "================================================" -ForegroundColor Cyan
if ($gesamtEntsperrt -gt 0) {
    Write-Host "ERFOLGREICH! Entsperrte PDFs: $gesamtEntsperrt" -ForegroundColor Green
}
if ($gesamtFehler -gt 0) {
    Write-Host "Fehler: $gesamtFehler" -ForegroundColor Red
}
Write-Host "================================================" -ForegroundColor Cyan
pause
